1. Create venv
2. pip install -r requirements.txt
3. python demo.py 
4. Open http://127.0.0.1:5000/ 
5. Enjoy!
